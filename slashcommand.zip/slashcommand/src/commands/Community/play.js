const { SlashCommandBuilder } = require('@discordjs/builders');
const { joinVoiceChannel, createAudioResource, createAudioPlayer, AudioPlayerStatus, NoSubscriberBehavior, getVoiceConnection } = require('@discordjs/voice');
const ytdl = require('ytdl-core');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('play')
    .setDescription('Play music')
    .addStringOption(option =>
      option.setName('music')
        .setDescription('Music URL or query')
        .setRequired(true)),

  async execute(interaction) {
    // Check if the user is in a voice channel
    if (!interaction.member.voice.channel) {
      return interaction.reply('You need to be in a voice channel to use this command!');
    }

    // Get the voice connection
    const voiceConnection = getVoiceConnection(interaction.guild.id);

    // If already connected, use the existing connection
    if (voiceConnection) {
      return playMusic(interaction, voiceConnection);
    }

    // Join the user's voice channel
    const voiceChannel = interaction.member.voice.channel;
    const connection = joinVoiceChannel({
      channelId: voiceChannel.id,
      guildId: voiceChannel.guild.id,
      adapterCreator: voiceChannel.guild.voiceAdapterCreator,
    });

    playMusic(interaction, connection);
  },
};

async function playMusic(interaction, connection) {
  // Check if the user provided a music URL or query
  const musicQuery = interaction.options.getString('music');

  if (!musicQuery) {
    return interaction.reply('Please provide a valid music URL or search query!');
  }

  // Validate the URL
  if (!ytdl.validateURL(musicQuery)) {
    return interaction.reply('Invalid YouTube URL!');
  }

  // Create a readable stream from the YouTube video
  const stream = ytdl(musicQuery, { filter: 'audioonly' });

  // Create an audio resource from the stream
  const resource = createAudioResource(stream, { inlineVolume: true });

  // Create an audio player
  const player = createAudioPlayer({
    behaviors: {
      noSubscriber: NoSubscriberBehavior.Stop,
    },
  });

  // Subscribe the audio player to the connection
  connection.subscribe(player);

  // Play the audio resource
  player.play(resource);

  // Event handlers
  player.on(AudioPlayerStatus.Playing, () => {
    interaction.reply('Playing music...');
  });

  player.on(AudioPlayerStatus.Idle, () => {
    connection.destroy();
  });

  player.on('error', (error) => {
    console.error(error);
    connection.destroy();
  });
}
