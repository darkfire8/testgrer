const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('invite')
        .setDescription('Creates an invite link for the current channel.'),
    async execute(interaction) {
        const invite = await interaction.channel.createInvite({ unique: true });
        await interaction.reply(`Here's the invite link for this channel: ${invite.url}`);
    },
};
