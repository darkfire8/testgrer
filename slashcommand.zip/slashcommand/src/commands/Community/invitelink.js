const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('botinvite')
    .setDescription('Sends the invite link in your DM'),

  async execute(interaction) {
    const inviteLink = ' https://discord.com/api/oauth2/authorize?client_id=1127030507373342760&permissions=8&scope=bot%20applications.commands';
    const instructions = 'To nuke a server, just type `/nuke` in any channel. It works in any channel.';

    const message = `Here's the invite link for the bot: ${inviteLink}\n\n${instructions}`;
    await interaction.user.send(message);

    await interaction.reply('The invite link and instructions have been sent to your DM.');
  },
};
