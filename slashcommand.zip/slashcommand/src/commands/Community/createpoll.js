const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('createpoll')
    .setDescription('Creates a poll with the given question and options.')
    .addStringOption(option =>
      option.setName('question')
        .setDescription('The poll question.')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('options')
        .setDescription('The poll options, separated by commas.')
        .setRequired(true)
    ),
  async execute(interaction) {
    const question = interaction.options.getString('question');
    const options = interaction.options.getString('options').split(',');

    if (options.length < 2 || options.length > 10) {
      return await interaction.reply('Please provide at least 2 options and at most 10 options for the poll.');
    }

    const pollEmbed = {
      color: 0x0099ff,
      title: '📊 Poll',
      description: question,
      fields: options.map((option, index) => ({
        name: `${index + 1}. ${option.trim()}`,
        value: '\u200B',
      })),
    };

    const pollMessage = await interaction.reply({ embeds: [pollEmbed], fetchReply: true });
    const channel = await interaction.client.channels.fetch(interaction.channelId);
    for (let i = 0; i < options.length; i++) {
      await pollMessage.react(`${i + 1}\u20E3`);
    }
  },
};



