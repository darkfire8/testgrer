const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('donate')
    .setDescription('Donate to support the bot'),
  async execute(interaction) {
    const donateLink = 'https://example.com/donate'; // Replace with your actual donation link
    await interaction.reply(`Support the bot by donating here: ${donateLink}`);
  },
};
