const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('inspire')
    .setDescription('Shares an inspirational quote.'),
    async execute(interaction, client){
        const randomResponses = ['The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt', 'Success is not final, failure is not fatal: It is the courage to continue that counts. - Winston Churchill', 'The only limit to our realization of tomorrow will be our doubts of today. - Franklin D. Roosevelt', 'Believe you can and you are halfway there. - Theodore Roosevelt', 'The best way to predict the future is to create it. - Peter Drucker','Believe in yourself and all that you are. Know that there is something inside you that is greater than any obstacle. - Christian D. Larson', 'The future depends on what you do today. - Mahatma Gandhi'];
const randomNumber = Math.floor(Math.random() * randomResponses.length);
const reply = randomResponses[randomNumber];

await interaction.reply({ content: reply }); 
    }
}