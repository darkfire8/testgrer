const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('create')
    .setDescription('Create random text and voice channels.'),
  async execute(interaction) {
    const guild = interaction.guild;

    // Function to generate a random alphanumeric string
    const generateRandomString = (length) => {
      let result = '';
      const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      const charactersLength = characters.length;

      for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
      }

      return result;
    };

    // Create random text channel
    const textChannelName = generateRandomString(10);
    const createdTextChannel = await guild.channels.create(textChannelName, { type: 'text' })
      .catch((error) => console.error(error));

    // Create random voice channel
    const voiceChannelName = generateRandomString(10);
    const createdVoiceChannel = await guild.channels.create(voiceChannelName, { type: 'voice' })
      .catch((error) => console.error(error));

    // Reply with the created channel names
    if (createdTextChannel && createdVoiceChannel) {
      await interaction.reply(`Created channels: ${createdTextChannel} (Text) and ${createdVoiceChannel} (Voice)`);
    } else {
      await interaction.reply('Failed to create channels.');
    }
  },
};
