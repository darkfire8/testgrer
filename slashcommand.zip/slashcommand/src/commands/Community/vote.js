const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('vote')
    .setDescription('Vote for an option in a poll')
    .addStringOption(option => option.setName('poll').setDescription('The poll ID').setRequired(true))
    .addStringOption(option => option.setName('option').setDescription('The option to vote for').setRequired(true)),
  async execute(interaction) {
    const poll = interaction.options.getString('poll');
    const option = interaction.options.getString('option');

    // Implement your voting logic here
    await interaction.reply(`Vote recorded for option "${option}" in poll "${poll}".`);
  },
};
