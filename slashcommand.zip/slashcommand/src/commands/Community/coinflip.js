const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('coinflip')
    .setDescription('Flips a coin.'),
  async execute(interaction) {
    try {
      // Generate a random number (0 or 1)
      const randomNumber = Math.floor(Math.random() * 2);

      // Determine the outcome based on the random number
      const result = randomNumber === 0 ? 'Heads' : 'Tails';

      // Send the result as a response
      await interaction.reply(result);
    } catch (error) {
      console.error(error);
      await interaction.reply('Failed to flip a coin. Please try again later.');
    }
  },
};
