const { SlashCommandBuilder } = require('discord.js');

// Array of cat facts
const catFacts = [
  "Cats have five toes on their front paws and four toes on their back paws.",
  "A group of cats is called a clowder.",
  "Cats sleep for an average of 12-16 hours a day.",
  // Add more cat facts here...
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('cat_fact')
    .setDescription('Shares a random cat fact.'),
  async execute(interaction) {
    try {
      // Select a random cat fact from the array
      const randomIndex = Math.floor(Math.random() * catFacts.length);
      const catFact = catFacts[randomIndex];

      // Send the cat fact as a response
      await interaction.reply(catFact);
    } catch (error) {
      console.error(error);
      await interaction.reply('Failed to fetch a cat fact. Please try again later.');
    }
  },
};
