const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('servericon')
        .setDescription('Shows the server icon.'),
    async execute(interaction) {
        const serverIcon = interaction.guild.iconURL();
        await interaction.reply(`The server icon: ${serverIcon}`);
    },
};
