const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('leave')
    .setDescription('Leave the current voice channel'),
  async execute(interaction) {
    const voiceChannel = interaction.guild.me.voice.channel;

    if (voiceChannel) {
      await voiceChannel.leave();
      await interaction.reply('Left the voice channel.');
    } else {
      await interaction.reply('I am not currently in a voice channel.');
    }
  },
};
