const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('join')
    .setDescription('Join a voice channel'),
  async execute(interaction) {
    const member = interaction.member;
    const voiceChannel = member.voice.channel;

    if (voiceChannel) {
      await voiceChannel.join();
      await interaction.reply(`Joined voice channel ${voiceChannel.name}`);
    } else {
      await interaction.reply('You must be in a voice channel to use this command.');
    }
  },
};
