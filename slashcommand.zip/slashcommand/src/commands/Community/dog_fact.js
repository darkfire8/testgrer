const { SlashCommandBuilder } = require('discord.js');

// Array of dog facts
const dogFacts = [
  "Dogs have an exceptional sense of hearing and can detect sounds at frequencies higher than humans can hear.",
  "Dogs have a sense of time and can recognize routines and anticipate certain events.",
  "The Basenji dog breed doesn't bark but instead makes unique yodel-like sounds.",
  // Add more dog facts here...
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dog_fact')
    .setDescription('Shares a random dog fact.'),
  async execute(interaction) {
    try {
      // Select a random dog fact from the array
      const randomIndex = Math.floor(Math.random() * dogFacts.length);
      const dogFact = dogFacts[randomIndex];

      // Send the dog fact as a response
      await interaction.reply(dogFact);
    } catch (error) {
      console.error(error);
      await interaction.reply('Failed to fetch a dog fact. Please try again later.');
    }
  },
};


