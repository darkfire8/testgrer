const { SlashCommandBuilder } = require('discord.js');

// Array of greetings
const greetings = [
  'Hello!',
  'Hi there!',
  'Greetings!',
  'Hey, how are you?',
  'Good to see you!',
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('greet')
    .setDescription('Greets the user.'),
  async execute(interaction) {
    try {
      // Select a random greeting from the array
      const randomGreeting = greetings[Math.floor(Math.random() * greetings.length)];

      // Send the greeting as a response
      await interaction.reply(randomGreeting);
    } catch (error) {
      console.error(error);
      await interaction.reply('Failed to greet. Please try again later.');
    }
  },
};
