const { SlashCommandBuilder } = require('discord.js');
const axios = require('axios');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('weather')
        .setDescription('Shows the weather for the specified location.')
        .addStringOption(option =>
            option.setName('location')
                .setDescription('The location for which you want to check the weather.')
                .setRequired(true)),
    async execute(interaction) {
        const location = interaction.options.getString('location');
        try {
            const apiKey = '39a8cbd7bd01187f321705386fc28a94';
            const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(
                location
            )}&appid=${apiKey}&units=metric`;

            const response = await axios.get(url);
            const weatherData = response.data;
            
            const cityName = weatherData.name;
            const temperature = weatherData.main.temp;
            const weatherDescription = weatherData.weather[0].description;
            
            const weatherMessage = `The current weather in ${cityName} is ${weatherDescription} with a temperature of ${temperature}°C.`;
            
            await interaction.reply(weatherMessage);
        } catch (error) {
            console.error(error);
            await interaction.reply('An error occurred while fetching the weather data.');
        }
    },
};
