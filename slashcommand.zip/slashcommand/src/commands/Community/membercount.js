const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('membercount')
        .setDescription('Shows the total number of members in the server.'),
    async execute(interaction) {
        const memberCount = interaction.guild.memberCount;
        await interaction.reply(`The server has ${memberCount} members.`);
    },
};
