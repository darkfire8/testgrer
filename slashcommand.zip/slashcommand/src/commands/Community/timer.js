const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timer')
    .setDescription('Set a timer')
    .addIntegerOption(option => option.setName('duration').setDescription('The duration of the timer in seconds').setRequired(true)),
  async execute(interaction) {
    const duration = interaction.options.getInteger('duration');
    const user = interaction.user;

    setTimeout(() => {
      interaction.followUp(`<@${user.id}> Timer ended!`);
    }, duration * 1000);

    await interaction.reply(`Timer set for ${duration} seconds. I'll tag you when it ends!`);
  },
};
