const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('userinfo')
        .setDescription('Displays information about a user')
        .addUserOption(option => option.setName('target').setDescription('The user to display information about')),
    async execute(interaction) {
        try {

            const badges = {
                BugHunterLevel1: '<:BugHunterLevel1:1122989104263602226>',
                BugHunterLevel2: '<:BugHunter2:1122989010021781545>',
                Partner: '<:Partner:1122988708199665664>',
                PremiumEarlySupporter: '<:PremiumEarlySupporter:1122988651941474344>',
                Staff: '<:Staff:1122988516327047178>',
                VerifiedDeveloper: '<:VerifiedDeveloper:1122988495523287071>',
                ActiveDeveloper: '<:ActiveDeveloper:1122991391602126989>',
            };
        
        const user = interaction.options.getUser('target') || interaction.user;
        const member = interaction.guild.members.cache.get(user.id)
        const icon = user.displayAvatarURL();
        const tag = user.tag;
        const userBadges = user.flags.toArray().map(badge => badges[badge]).join(' ') || 'None';
        const botStatus = user.bot ? 'Yes' : 'No';

        const embed = new EmbedBuilder()
            .setTitle(`${user.username}'s Information`)
            .setAuthor({ name: tag, iconURL: icon})
            .setColor("Blue")
            .setThumbnail(user.displayAvatarURL({ dynamic: true }))
            .setThumbnail(icon)
            .addFields({ name: `Display Name`, value: `${user}`, inline: false})
            .addFields({ name: `Username`, value: user.username})
            .addFields({ name: `ID`, value: user.id })
            .addFields({ name: `Roles`, value: `${member.roles.cache.map(r => r).join(' ')}`, inline: false})
            .addFields({ name: `Discord Member Since | Account Created`, value: new Date(user.createdTimestamp).toLocaleDateString() })
            .addFields({ name: `Member Since | Joined Server`, value: new Date(member.joinedTimestamp).toLocaleDateString() })
            .addFields({ name: `Total Boost`, value: member.premiumSince ? 'Yes' : 'No', inline: false})
            .addFields({ name: `Server Boost`, value: member.premiumSince ? 'Yes' : 'No', inline: false,})
            .addFields({ name: `Boosted Server`, value: user.premiumSince ? 'Yes' : 'No', inline: false,})
            .addFields({ name: `Nitro Booster`, value: user.premiumSince ? 'Yes' : 'No', inline: false})
            .addFields({ name: `Badges`, value: userBadges, inline: false,})
            .addFields({ name: `BOT`, value: botStatus, inline: false,})

        await interaction.reply({ embeds: [embed], ephemeral: true });
        } catch (error) {
            console.error(error);
            await interaction.reply({ content: 'An error occurred while executing the command.', ephemeral: true});
        }
    },
};