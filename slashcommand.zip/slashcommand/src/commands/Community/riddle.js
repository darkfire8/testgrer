const { SlashCommandBuilder } = require('discord.js');

// Array of riddles
const riddles = [
  "I speak without a mouth and hear without ears. I have no body, but I come alive with the wind. What am I?",
  "What has keys but can't open locks?",
  "The more you take, the more you leave behind. What am I?",
  // Add more riddles here...
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('riddle')
    .setDescription('Shares a riddle.'),
  async execute(interaction) {
    try {
      // Select a random riddle from the array
      const randomIndex = Math.floor(Math.random() * riddles.length);
      const riddle = riddles[randomIndex];

      // Send the riddle as a response
      await interaction.reply(riddle);
    } catch (error) {
      console.error(error);
      await interaction.reply('Failed to fetch a riddle. Please try again later.');
    }
  },
};
