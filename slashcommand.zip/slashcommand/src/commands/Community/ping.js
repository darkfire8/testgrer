const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ping')
        .setDescription("Shows the bot's latency."),
    async execute(interaction) {
        const startTimestamp = Date.now();
        const reply = await interaction.reply('Pinging...');
        const endTimestamp = Date.now();
        const latency = endTimestamp - startTimestamp;
        await reply.edit(`Bot's latency: ${latency}ms, API latency: ${interaction.client.ws.ping}ms`);
    },
};
