const axios = require('axios');
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('convert')
    .setDescription('Convert currency')
    .addNumberOption(option => option.setName('amount').setDescription('The amount to convert').setRequired(true))
    .addStringOption(option => option.setName('from').setDescription('The currency to convert from').setRequired(true))
    .addStringOption(option => option.setName('to').setDescription('The currency to convert to').setRequired(true)),
  async execute(interaction) {
    const amount = interaction.options.getNumber('amount');
    const fromCurrency = interaction.options.getString('from').toUpperCase();
    const toCurrency = interaction.options.getString('to').toUpperCase();

    const conversionRate = await getConversionRate(fromCurrency, toCurrency);
    if (conversionRate === null) {
      await interaction.reply('Unable to fetch conversion rates. Please try again later.');
      return;
    }

    const convertedAmount = amount * conversionRate;
    await interaction.reply(`${amount} ${fromCurrency} is equal to ${convertedAmount} ${toCurrency}`);
  },
};

async function getConversionRate(fromCurrency, toCurrency) {
  const apiKey = '8ed4bda1184c32c4e329a291'; // Replace with your actual API key
  const url = `https://v6.exchangerate-api.com/v6/${apiKey}/pair/${fromCurrency}/${toCurrency}`;

  try {
    const response = await axios.get(url);
    const { conversion_rate: conversionRate } = response.data;
    return conversionRate;
  } catch (error) {
    console.error(error);
    return null;
  }
}
