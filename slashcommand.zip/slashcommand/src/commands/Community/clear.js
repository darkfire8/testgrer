const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('clear')
        .setDescription('Clears the specified number of messages.')
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('The number of messages to clear.')
                .setRequired(true)),
    async execute(interaction) {
        const amount = interaction.options.getInteger('amount');

        if (amount <= 0 || amount > 100) {
            return interaction.reply('Please provide a number between 1 and 100.');
        }

        await interaction.channel.bulkDelete(amount);
        await interaction.reply(`Cleared ${amount} messages.`);
    },
};
