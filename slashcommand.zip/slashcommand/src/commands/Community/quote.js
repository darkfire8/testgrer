const { SlashCommandBuilder } = require('discord.js');

// Array of quotes
const quotes = [
  "The only way to do great work is to love what you do. - Steve Jobs",
  "Believe you can and you're halfway there. - Theodore Roosevelt",
  "The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt",
  // Add more quotes here...
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('quote')
    .setDescription('Shares an inspirational quote.'),
  async execute(interaction) {
    try {
      // Select a random quote from the array
      const randomIndex = Math.floor(Math.random() * quotes.length);
      const quote = quotes[randomIndex];

      // Send the quote as a response
      await interaction.reply(quote);
    } catch (error) {
      console.error(error);
      await interaction.reply('Failed to fetch an inspirational quote. Please try again later.');
    }
  },
};
