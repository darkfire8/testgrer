const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('set-nickname')
    .setDescription('Set the nickname of a user')
    .addUserOption(option => option.setName('user').setDescription('User to set the nickname for').setRequired(true))
    .addStringOption(option => option.setName('nickname').setDescription('Nickname to set').setRequired(true)),
  async execute(interaction) {
    if (!interaction.member.permissions.has('MANAGE_NICKNAMES')) {
      return interaction.reply({
        content: 'You do not have permission to use this command.',
        ephemeral: true,
      });
    }
    const user = interaction.options.getUser('user');
    const nickname = interaction.options.getString('nickname');
    const member = interaction.guild.members.cache.get(user.id);
    await member.setNickname(nickname);
    interaction.reply(`Nickname set to ${nickname} for ${user.tag}.`);
  },
};
