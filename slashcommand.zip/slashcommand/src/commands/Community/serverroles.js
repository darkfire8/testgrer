const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('serverroles')
        .setDescription('Shows the roles in the server.'),
    async execute(interaction) {
        const roles = interaction.guild.roles.cache.map(role => role.name);
        await interaction.reply(`The server roles are: ${roles.join(', ')}`);
    },
};
