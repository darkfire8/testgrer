const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('dice')
        .setDescription('Rolls a dice 1-100.'),
    async execute(interaction) {
        const rollResult = Math.floor(Math.random() * 100) + 1;
        await interaction.reply(`You rolled a ${rollResult}!`);
    },
};
