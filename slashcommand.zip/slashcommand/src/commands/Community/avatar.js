const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('avatar')
        .setDescription('Shows the avatar of the specified user.')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('Select the user to show their avatar.')
                .setRequired(true)),
    async execute(interaction) {
        const user = interaction.options.getUser('user');
        const avatar = user.displayAvatarURL({ dynamic: true, format: 'png', size: 1024 });
        await interaction.reply(`Avatar of ${user.username}: ${avatar}`);
    },
};
