const { SlashCommandBuilder } = require('discord.js');

// Array of compliments
const compliments = [
  'You are amazing!',
  'You have a beautiful smile.',
  'Your kindness is inspiring.',
  'You are incredibly talented.',
  'You make the world a better place.',
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('compliment')
    .setDescription('Gives a compliment.'),
  async execute(interaction) {
    try {
      // Select a random compliment from the array
      const randomCompliment = compliments[Math.floor(Math.random() * compliments.length)];

      // Send the compliment as a response
      await interaction.reply(randomCompliment);
    } catch (error) {
      console.error(error);
      await interaction.reply('Failed to give a compliment. Please try again later.');
    }
  },
};
