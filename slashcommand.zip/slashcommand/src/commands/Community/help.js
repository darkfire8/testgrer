const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('This is the help command!'),
  async execute(interaction, client) {
    const commandList = `Bot Commands:
/greet - Greets the user.

/compliment - Gives a compliment.

/inspire - Shares an inspirational quote.

/coinflip - Flips a coin.

/cat_fact - Shares a random cat fact.

/dog_fact - Shares a random dog fact.

/quote - Shares an inspirational quote.

/riddle - Shares a riddle.

/magic_ball [question] - Provides an answer from the magic 8-ball.

/meme - Shares a random meme.

/createpoll [question] [option1] [option2] ... - Creates a poll with the given question and options.

/bot_help - Shows the available bot commands.

/translate [text] - Translates the provided text to a different language.

/weather [location] - Shows the weather for the specified location.

/roll_dice - Rolls a dice 1-6.

/clear [amount] - Clears the specified number of messages.

/say [message] - Repeats the provided message.

/userinfo [user] - Shows information about the specified user.

/serverinfo - Shows information about the server.

/invite - Creates an invite link for the current channel.

/ping - Shows the bot's latency.

/avatar [user] - Shows the avatar of the specified user.

/servericon - Shows the server icon.

/serverroles - Shows the roles in the server.

/membercount - Shows the total number of members in the server.`;

    await interaction.reply(commandList);

        // Set the bot's activity to "Playing /help"
        await client.user.setActivity('/help', { type: 'PLAYING' });
  },
};



