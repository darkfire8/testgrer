const {
    ChatInputCommandInteraction,
    EmbedBuilder,
    ChannelType,
    GuildVerificationLevel,
    GuildExplicitContentFilter,
    GuildNSFWLevel,
    SlashCommandBuilder,
  } = require("discord.js");
  
  module.exports = {
    data: new SlashCommandBuilder()
      .setName("serverinfo")
      .setDescription("Shows the server info"),
  
    /**
     * @param {ChatInputCommandInteraction} interaction
     */
    async execute(interaction) {
      const { guild } = interaction;
      const { channels, emojis, stickers } = guild;
  
      const getChannelTypeSize = (type) =>
        channels.cache.filter((channel) => type.includes(channel.type)).size;
  
      const totalChannels = getChannelTypeSize([
        ChannelType.GuildText,
        ChannelType.GuildNews,
        ChannelType.GuildVoice,
        ChannelType.GuildStageVoice,
        ChannelType.GuildForum,
        ChannelType.GuildPublicThread,
        ChannelType.GuildPrivateThread,
        ChannelType.GuildNewsThread,
        ChannelType.GuildCategory,
      ]);
  
      interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0xbd8310)
            .setTitle(`<:info:1082726225937711184> ${guild.name} | Information`)
            .setThumbnail(guild.iconURL({ size: 1024 }))
            .setImage(guild.bannerURL({ size: 1024 }))
            .addFields(
              { name: "Description", value: `📝 ${guild.description || "Empty"}` },
              {
                name: "General",
                value: [
                  `📜 **Created** <t:${parseInt(
                    guild.createdTimestamp / 1000
                  )}:R>`,
                  `💳 **ID** ${guild.id}`,
                  `👑 **Owner** <@${guild.ownerId}>`,
                  `🌍 **Language** ${new Intl.DisplayNames(["en"], {
                    type: "language",
                  }).of(guild.preferredLocale)}`,
                  `💻 **Vanity URL** ${guild.vanityURLCode || "Empty"}`,
                ].join("\n"),
              },
              {
                name: "Features",
                value:
                  guild.features
                    ?.map((feature) => `- ${feature}`)
                    ?.join("\n") || "Brak",
                inline: true,
              },
              {
                name: "Security",
                value: [
                  `👀 **Explicit Filter** ${GuildExplicitContentFilter[guild.explicitContentFilter] || "Empty"}`,
                  `🔞 **NSFW Level** ${GuildNSFWLevel[guild.nsfwLevel] || "Empty"}`,
                  `🔒 **Verification Level** ${GuildVerificationLevel[guild.verificationLevel] || "Empty"}`,
                ].join("\n"),
                inline: true,
              },
              {
                name: `Channels, Threads & Categories (${totalChannels})`,
                value: [
                  `💬 **Text** ${getChannelTypeSize([
                    ChannelType.GuildText,
                    ChannelType.GuildForum,
                    ChannelType.GuildNews,
                  ])}`,
                  `🎙 **Voice** ${getChannelTypeSize([
                    ChannelType.GuildVoice,
                    ChannelType.GuildStageVoice,
                  ])}`,
                  `🧵 **Threads** ${getChannelTypeSize([
                    ChannelType.GuildPublicThread,
                    ChannelType.GuildPrivateThread,
                    ChannelType.GuildNewsThread,
                  ])}`,
                  `📑 **Categories** ${getChannelTypeSize([
                    ChannelType.GuildCategory,
                  ])}`,
                ].join("\n"),
                inline: true,
              },
              {
                name: `Emojis & Stickers (${
                  emojis.cache.size + stickers.cache.size
                })`,
                value: [
                  `📺 **Animated** ${
                    emojis.cache.filter((emoji) => emoji.animated).size
                  }`,
                  `🗿 **Static** ${
                    emojis.cache.filter((emoji) => !emoji.animated).size
                  }`,
                  `🏷 **Stickers** ${stickers.cache.size}`,
                ].join("\n"),
                inline: true,
              },
              {
                name: "Nitro",
                value: [
                  `📈 **Tier** ${guild.premiumTier || "Empty"}`,
                  `💪🏻 **Boosts** ${guild.premiumSubscriptionCount}`,
                ].join("\n"),
                inline: true,
              },
              { name: "Banner", value: guild.bannerURL() ? "** **" : "Empty" }
            ),
        ],
        ephemeral: false,
      });
    },
  
    catch(error) {
      console.error(error);
      interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("Red")
            .setDescription("Something went wrong Please try again later."),
        ],
        ephemeral: true,
      });
    },
  };
  