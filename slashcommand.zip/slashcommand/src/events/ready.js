const { ActivityType } = require('discord.js');

module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        console.log('Ready!');

        client.user.setPresence({ activities: [{ name: '/botinvite', type: ActivityType.Playing }] });

        const statusArray = [
            { content: '/botinvite', type: ActivityType.Playing, status: 'online' },
            { content: '/help', type: ActivityType.Watching, status: 'online' },
        ];

        async function pickPresence() {
            const option = Math.floor(Math.random() * statusArray.length);

            try {
                await client.user.setPresence({
                    activities: [
                        {
                            name: statusArray[option].content,
                            type: statusArray[option].type,
                        },
                    ],
                    status: statusArray[option].status,
                });
            } catch (error) {
                console.error(error);
            }
        }

        // Call the function to set the initial presence
        await pickPresence();

        // Set presence every 10 seconds
        setInterval(pickPresence, 10000);
    },
};
